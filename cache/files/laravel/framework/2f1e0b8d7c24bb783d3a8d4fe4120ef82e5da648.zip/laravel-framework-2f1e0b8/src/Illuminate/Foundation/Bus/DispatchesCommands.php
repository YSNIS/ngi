<?php

namespace Illuminate\Foundation\Bus;

/**
 * @deprecated since version 5.1. Use the DispatchesJobs trait directly.
 */
trait DispatchesCommands
{
    use DispatchesJobs;
}
